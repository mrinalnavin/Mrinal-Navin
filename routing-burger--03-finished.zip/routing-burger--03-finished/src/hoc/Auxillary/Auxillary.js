import React from 'react'

function Aux(props){
    return(
        <div>
            {props.children}
        </div>
    )
}


export default Aux;